const Sdata = {
  shopItems: [
    {
      id: 7,
      cover: "./images/shops/1.png",
      name: "UNICORN MakeUp Brush",
      price: "180",
      discount: "25",
    },
    {
      id: 8,
      cover: "./images/shops/2.png",
      name: "Combo",
      price: "120",
      discount: "10",
    },
    {
      id: 9,
      cover: "./images/shops/33.png",
      name: "MAC Foundation ",
      price: "20",
      discount: "50 ",
    },
    {
      id: 10,
      cover: "./images/shops/44.png",
      name: "EYE Mini Makeup Set",
      price: "999",
      discount: "10 ",
    },
    {
      id: 11,
      cover: "./images/shops/55.png",
      name: "Lipstick",
      price: "80",
      discount: "20 ",
    },
    {
      id: 12,
      cover: "./images/shops/66.png",
      name: "Nail Polish",
      price: "400",
      discount: "20 ",
    },
    {
      id: 13,
      cover: "./images/shops/88.png",
      name: "Compact Powder",
      price: "60",
      discount: "5 ",
    },
    {
      id: 14,
      cover: "./images/shops/99.png",
      name: "NARS Lipstick",
      price: "120",
      discount: "10",
    },
    {
      id: 15,
      cover: "./images/shops/10.png",
      name: "Eye Pallet",
      price: "5",
      discount: "2",
    },
  ],
}
export default Sdata
