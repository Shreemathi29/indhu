const Data = {
  productItems: [
    {
      id: 1,
      discount: 50,
      cover: "./images/flash/2.png",
      name: "Rice",
      price: 100,
    },
    {
      id: 2,
      discount: 40,
      cover: "./images/flash/6.png",
      name: "Ponni Rice",
      price: 20,
    },
    {
      id: 3,
      discount: 40,
      cover: "./images/flash/7.png",
      name: "Basmati Rice",
      price: 200,
    },
    {
      id: 4,
      discount: 40,
      cover: "./images/flash/8.png",
      name: "Rice",
      price: 50,
    },
    {
      id: 5,
      discount: 50,
      cover: "./images/flash/2.png",
      name: "Ponni Rice",
      price: 100,
    },
    {
      id: 6,
      discount: 50,
      cover: "./images/flash/6.png",
      name: "Bullet Rice",
      price: 100,
    },
  ],
}
export default Data
