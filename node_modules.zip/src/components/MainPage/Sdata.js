const Sdata = [
  {
    id: 1,
    title: "50% Off For Your First Shopping",
    desc: "Cosmetics designed to enhance or alter one's appearance (makeup) can be used to conceal blemishes, enhance one's natural features.",
    cover: "./images/SlideCard/1.png",
  },
  {
    id: 2,
    title: "50% Off For Your First Shopping",
    desc: "She wore light dabs of face powder on her cheeks to hide the permanent track marks left by so many tears.",
    cover: "./images/SlideCard/2.png",
  },
  {
    id: 3,
    title: "50% Off For Your First Shopping",
    desc: "People who love to eat are always the best people. To eat is a necessity, but to eat intelligently is an art.",
    cover: "./images/SlideCard/7.png",
  },
  {
    id: 4,
    title: "50% Off For Your First Shopping",
    desc: "The powder is mixed with water and tastes exactly like powder mixed with water",
    cover: "./images/SlideCard/88.png",
  },
]
export default Sdata
