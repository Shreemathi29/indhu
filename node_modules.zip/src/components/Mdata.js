const MData = {
    proItems: [
      {
        id: 21,
        discount: 50,
        cover: "./images/flash/2.png",
        name: "Rice",
        price: 100,
      },
      {
        id: 22,
        discount: 40,
        cover: "./images/flash/6.png",
        name: "Ponni Rice",
        price: 20,
      },
      {
        id: 23,
        discount: 40,
        cover: "./images/flash/7.png",
        name: "Basmati Rice",
        price: 200,
      },
      {
        id: 24,
        discount: 40,
        cover: "./images/flash/8.png",
        name: "Bullet Rice",
        price: 50,
      },
      {
        id: 25,
        discount: 50,
        cover: "./images/flash/2.png",
        name: "Ponni Rice",
        price: 100,
      },
      {
        id: 26,
        discount: 50,
        cover: "./images/flash/6.png",
        name: "Rice",
        price: 100,
      },
    ],
  }
  export default MData
  