/*import React from "react";
import { MenuList } from "../pages/MenuList";
import MenuItem from "../pages/MenuItem";
//import Search from "./Search";
import "./Menu.css";

function Products() {
  return (
    <div className="menu">
      <h1 className="menuTitle">Books</h1>
      <div className="menuList">
        {MenuList.map((menuItem, key) => {
          return ( 
            <div>
           
            <MenuItem
              key={key}
             
             
             
              image={menuItem.image}
              
              name={menuItem.name}
              author={menuItem.author}
              price={menuItem.price}
              year={menuItem.year}
              publisher={menuItem.publisher}

            />
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default Products;*/
import React from 'react'

function Products() {
  return (
    <div>Products</div>
  )
}

export default Products;