/*import React from 'react';

export default function Trending() {
  return (
    <>
      <h1 className='comic'>COMICSTORES</h1>
    </>
  );
}

*/
import Pepperoni from "./pages/images/1.png";
import Margherita from "./images/2.png";
import PedroTechSpecial from "./images/3.png";
import Vegan from "./images/4.png";
import Pineapple from "./images/5.png";
import Expensive from "./images/6.png";
import Pepperonis from "./images/7.png";
import Margheritas from "./images/8.png";
import PedroTechSpecials from "./images/9.png";
import Vegans from "./images/10.png";
import Pineapples from "./images/11.png";
//import Expensive from "../images/expensive.png";*/
export const MenuList = [
  {
    name: "Arthur Conan Doyle",
    image: Pepperoni,
    author:"Sherlock holmes",
    price: 45.99,
    publisher:"Kindle Publication",
    year:"1, Jan, 2020"
  },
  {
    name: "Margherita Pizza",
    image: Margherita,
    author:"Sherlock holmes",
    price: 19.99,
    publisher:"Kindle Publication",
    year:"1, Mar, 2021"
  },
  {
    name: "PedroTech Special Pizza",
    image: PedroTechSpecial,
    author:"Sherlock holmes",
    price: 256.53,
    publisher:"Squit Publication",
    year:"1, Jan, 2018"
  },
  {
    name: "Vegan Pizza",
    image: Vegan,
    author:"Sherlock holmes",
    price: 87.99,
    publisher:"Lyca Publication",
    year:"1, Sep, 2020"
  },
  {
    name: "Pineapple Pizza",
    image: Pineapple,
    author:"Sherlock holmes",
    price: 42.99,
    publisher:"Kaddle Publication",
    year:"25, Oct, 2020"
  },
  {
    name: "Very Expensive Pizza",
    image: Expensive,
    author:"Sherlock holmes",
    price: 199.99,
    publisher:"Shr Publication",
    year:"8, Apr, 2002"
  },
  {
    name: "Pepperoni Pizza",
    image: Pepperonis,
    author:"Sherlock holmes",
    price: 151.99,
    publisher:"Shree Publication",
    year:"29, Apr, 2020"
  },
  {
    name: "Margherita Pizza",
    image: Margheritas,
    author:"Sherlock holmes",
    price: 121.99,
    publisher:"Sonu Publication",
    year:"1, July, 2020"
  },
  {
    name: "PedroTech Special Pizza",
    image: PedroTechSpecials,
    author:"Sherlock holmes",
    price: 256.53,
    publisher:"Naveen Publication",
    year:"1, Jan, 2020"
  },
  {
    name: "Vegan Pizza",
    image: Vegans,
    author:"Sherlock holmes",
    price: 77.99,
    publisher:"Nett Publication",
    year:"1, Jan, 2020"
  },
  {
    name: "Pineapple Pizza",
    image: Pineapples,
    author:"Sherlock holmes",
    price: 40.99,
    publisher:"Kindle Publication",
    year:"8, July, 2020"
  },
  
];