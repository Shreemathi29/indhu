import React from 'react'

function Pro() {
  return (
    <div>Pro</div>
  )
}

export default Pro;